**To delete a delivery channel**

The following command deletes the default delivery channel::

    aws configservice delete-delivery-channel --delivery-channel-name default